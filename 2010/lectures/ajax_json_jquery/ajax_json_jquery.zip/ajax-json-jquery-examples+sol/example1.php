<?php
 print '<div class="entry">
          <h3 class="word">ABANDON</h3>
          <div class="function">v./n.</div>
          <div class="definition">
            to give up completely
          </div>
        </div>
        
        <div class="entry">
          <h3 class="word">ABASH</h3>
          <div class="function">v.</div>
            <div class="definition">
              to make embarrassed
            </div>
          </div>
        </div>  
       ';
?>