<?php

$data = '
[
  {
    "word": "ABANDON",
    "function": "v./n.",
    "definition": "to give up completely"
  },
  {
    "word": "ABASH",
    "function": "v.",
    "definition": "to make embarrassed"
  },
  {
    "word": "ABATE",
    "function": "v.",
    "definition": "to make less in amount; wane"
  },
  {
    "word": "ABBREVIATE",
    "function": "v.",
    "definition": "to make shorter; to shorten a word or phrase"
  }
]
';

print($_GET['callback'].'('.$data.')');

?>