<?php

ini_set('display_errors',1);
error_reporting(E_ALL);

require_once 'JSON.php';
$json= new Services_JSON();

//start the database connection
$dbhost='sql.mit.edu';
$dbuser='username';
$dbpass='password';

?>