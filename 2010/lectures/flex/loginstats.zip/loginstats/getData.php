<?php 
require_once 'database.php';

$conn=mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');


$dbname='6470+loginstats';
mysql_select_db($dbname) or die ('Error, could not access database '.$dbname);

$returnObject = array();

$queryMinTime = "SELECT MIN(timeEntered) FROM `users` ";
$resultMinTime= mysql_query($queryMinTime ) or die("Error performing query1 on $queryMinTime ");
$minTimeRow = mysql_fetch_row($resultMinTime);

$minTime =  $minTimeRow[0];

$query1 = "SELECT username, TIME_TO_SEC(TIMEDIFF(timeEntered, '$minTime')) FROM users ";
$result1= mysql_query($query1) or die("Error performing query1 on getData.php here: $query1");

while($row = mysql_fetch_row($result1))
	{
		
		$item = new stdclass();
		$item -> time = $row[1];
		$item -> namelength = strlen($row[0]);
		$returnObject[] = $item; 
	}

echo $json->encode($returnObject);

?>
