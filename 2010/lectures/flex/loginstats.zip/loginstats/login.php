<?php 
require_once 'database.php';

session_start();

$conn=mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');

$username = $_POST['username'];
$password = md5($_POST['password']);

$dbname='6470+loginstats';
mysql_select_db($dbname) or die ('Error, could not access database '.$dbname);

$returnObject = new stdclass();
$returnObject->username = $username;
$returnObject->md5pass = $password;

//The COUNT(*) function returns the number of records in a table:
$query1 = "SELECT COUNT(*) FROM users WHERE  `username` = '$username' AND `password`= '$password' LIMIT 1;";
$result1= mysql_query($query1) or die("Error performing query1 on login.php: $query1");
$row = mysql_fetch_row($result1);
$numMatches = $row[0];
$return="success";
if($numMatches=="1"){
	//successful login!
	$_SESSION['username']=$username;
	$returnObject->status = "success";
}else{
	$return ="fail";
	$returnObject->status = "fail";
	
	

}
echo $json->encode($returnObject);

?>
