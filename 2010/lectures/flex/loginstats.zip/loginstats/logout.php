<?php 
session_start();
$_SESSION['username']="";

?>