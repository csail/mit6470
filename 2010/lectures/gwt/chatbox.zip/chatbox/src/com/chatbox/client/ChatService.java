package com.chatbox.client;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

// This is the interface for the chat server's service

// Make sure this path "chat" is set -- and must be the same as the 
// mapping set in war/WEB-INF/web.xml
@RemoteServiceRelativePath("chat")
public interface ChatService extends RemoteService {

	// add a message to the chat room
	public void addMessage(String msg);
	
	// get all messages
	public List<Message> getMessages();
	
}
