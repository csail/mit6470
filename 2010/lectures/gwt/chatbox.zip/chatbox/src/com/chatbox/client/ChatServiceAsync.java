package com.chatbox.client;

import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;

// This is the asynchronous interface used by the client --
// so that every call to the server is returned via a callback.
public interface ChatServiceAsync {

	void addMessage(String msg, AsyncCallback<Void> callback);

	void getMessages(AsyncCallback<List<Message>> callback);

}
