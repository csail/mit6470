package com.chatbox.client;

import java.util.List;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class Chatbox implements EntryPoint {

	// UI elements in the app
	VerticalPanel messages = new VerticalPanel();
	TextBox messageBox = new TextBox();
	Button messageSubmit = new Button();

	// Chat service for making RPC calls to server
	ChatServiceAsync chatService = GWT.create(ChatService.class);
	
	// this function is called when the page loads
	public void onModuleLoad() {
		// container of everything
		VerticalPanel container = new VerticalPanel();
		
		// panel containing input box and button
		HorizontalPanel inputPanel = new HorizontalPanel();
		inputPanel.add(messageBox);
		inputPanel.add(messageSubmit);
		messageSubmit.setText("Enter");
		
		container.add(messages);
		container.add(inputPanel);
		
		// adds container to the "content" div, see Chatbox.html
		RootPanel.get("content").add(container);
		
		// submit button, when clicked, will make a call to the server
		// to send the message.
		messageSubmit.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				// disable button while sending
				messageBox.setEnabled(false);
				// send message
				chatService.addMessage(messageBox.getText(), new AsyncCallback<Void>() {
					public void onSuccess(Void result) {
						// when finished, clear text and re-enable
						messageBox.setText("");
						messageBox.setEnabled(true);
					}
					public void onFailure(Throwable caught) {
						// do nothing =)
					}
				});
			}
		});
		
		// continuously poll server for new messages
		Timer timer = new Timer() {
			@Override
			public void run() {
				chatService.getMessages(new AsyncCallback<List<Message>>() {
					public void onSuccess(List<Message> result) {
						// loop through all the messages that are not already in the 
						// messages panel
						for (int i = messages.getWidgetCount(); i < result.size(); i++) {
							messages.add(new MessageWidget(result.get(i)));
						}
					}
					public void onFailure(Throwable caught) {
						// do nthing =)
					}
				});
			}
		};
		// repeat every 500ms
		timer.scheduleRepeating(500);
		
	}
	
	
}
