package com.chatbox.client;

import java.util.Date;

import com.google.gwt.user.client.rpc.IsSerializable;

// This is a Message class, make sure it implements IsSerializable
// if you intend to send it over RPC calls to the server
public class Message implements IsSerializable {
	
	public String msg;
	public Date timestamp;
	
	public Message(String msg, Date timestamp) {
		this.msg = msg;
		this.timestamp = timestamp;
	}
	
	// A constructor with no argument is required if you wish to
	// send objects of this class over RPC calls
	public Message(){}
}
