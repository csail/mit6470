package com.chatbox.client;

import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

// This is a custom widget for displaying each message.
public class MessageWidget extends Composite {

	Label messageLabel = new Label();
	Label timestampLabel = new Label();
	
	public MessageWidget(Message msg) {
		VerticalPanel container = new VerticalPanel();
		container.add(messageLabel);
		container.add(timestampLabel);

		// This sets what the Composite points to
		initWidget(container);
		
		messageLabel.setText(msg.msg);
		timestampLabel.setText(msg.timestamp.toLocaleString());
		
		// addStyleName sets the CSS class name of the widget
		container.addStyleName("message-container");
		timestampLabel.addStyleName("timestamp-label");
	}
	
}
