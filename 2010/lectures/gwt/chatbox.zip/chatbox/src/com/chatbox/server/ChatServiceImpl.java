package com.chatbox.server;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.chatbox.client.ChatService;
import com.chatbox.client.Message;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

// This is the actual implementation of the ChatService and must be in the server/ folder.
@SuppressWarnings("serial")
public class ChatServiceImpl extends RemoteServiceServlet implements ChatService {

	List<Message> messages = new ArrayList<Message>();
	
	public void addMessage(String msg) {
		messages.add(new Message(msg, new Date()));
	}

	public List<Message> getMessages() {
		return messages;
	}

}
