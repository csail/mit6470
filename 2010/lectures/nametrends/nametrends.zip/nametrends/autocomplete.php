<?php

//start the database connection
require_once 'database.php';

$conn=mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
$db='6470+babynames';
mysql_select_db($db) or die ('Error, could not access database '.$db);

//the javascript function that calls this php file sends a get parameter of the string the user has typed.
//we need to fetch it.
$queryString= $_GET["q"];
$g= $_GET["gender"];

$gender ="m";
if($g=="Female"){
	$gender ="f";
}

// Is the string length greater than 0?
if(strlen($queryString) >0) {
	// Run the query: 
	// We use LIKE ‘$queryString%’
	// The percentage sign is a wild-card, in my example of countries it works like this…
	// $queryString = ‘Uni’;
	// Returned data = ‘United States, United Kindom’;

	// Our data has many instances of each name, so we select *distinct* to get only one copy of each.
	//$query = "SELECT DISTINCT `name`, `gender` FROM `ssadata` WHERE `name` LIKE '$queryString%' ORDER BY `name` ASC LIMIT 10";   AND `gender` = '$gender' 
	$query = "SELECT DISTINCT `name` FROM `ssadata` WHERE `name`  LIKE '$queryString%'   AND `gender` = '$gender' ORDER BY `name` ASC LIMIT 10";
	$result= mysql_query($query) or die('Error performing query on autocomplete.php');
	while ($row = mysql_fetch_row($result)) {
		echo $row[0]."\n";
	}
} 

?>
