<?php

require_once '/json/JSON.php';
$json= new Services_JSON();

//start the database connection
$dbhost='sql.mit.edu';
$dbuser='username';
$dbpass='password';
$dbname='username+databasename';

?>