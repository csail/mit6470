<?php
require_once '../json/JSON.php';
$json= new Services_JSON();

function returnComments(){
    global $json;
    $returnObject = array();
    
    $query1 = "SELECT * FROM comments ORDER BY time DESC LIMIT 10;";
    $result1= mysql_query($query1) or die('Error performing query1 on getData.php');
    while($row = mysql_fetch_row($result1)){
        $entry = new stdclass();
        $entry ->username = $row[0];
        $entry ->time = $row[1];
        $entry ->comment = $row[2];
        
        $returnObject[]= $entry;
    }
    $output = $json->encode($returnObject);
    return $output;

}

?>