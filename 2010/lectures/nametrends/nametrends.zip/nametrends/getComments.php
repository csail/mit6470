<?php 

require_once 'functions.php';

//start the database connection
require_once 'database.php';

$conn=mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');


mysql_select_db($dbname) or die ('Error, could not access database '.$dbname);


echo returnComments();
?>
