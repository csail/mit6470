<?php 
/*
Overview:
1. The javascript function that called this php file sent 5 variables we will need as parameters to our database queries.  We first get that data out of a php-defined variable called $_POST.

2. We then connect to the sql server and choose the right database ('6470+babynames') in this case.

3. There are two steps to our database query.  Ultimately, we will write a query asking for the popularities of an array of names over a range of years.  In order to do that, we may have to get the top 1, 5, 10, or 20 names first because that is a key feature of this site.  

4.  Finding the top X names of a particular gender.  Select the all entries where the year falls within our range of years (inclusive).  We only care about two fields of this table, the name (Anna, Bill, Cindy, etc.) and the percentage (field name= 'percent') of babies named that name in that year.  HOWEVER, we actually want to aggregate all the percentages.  If Anna had 1% in 2005 and 2% in 2006, she has 3% for the entire range 2005-2006.  We use SUM(percent) to aggregate and sum the percents of all the names over that range.  We also sort by that aggregate percentage, so that the first N results are the N most popular names.

5.  For our list of names, getting all the datapoints.  For each name we data in the following form:  
{"John":
	{"label":"John",
	 "data":[[1880,0.081536],[1881,0.08098],[1882,0.078308],[2006,0.006923]]
	},
"James":
	{"label":"James",
	 "data":[[1880,0.050053],[1881,0.05025],[1882,0.048278],[1883,0.046447]]
	}
}
Where the data are the points that we will plot in the form (year, percent in that year).
*/

//get all the variables from POST
$ranks=$_POST['ranks']; //"top1", "top5", "top10" or "top20"
$namesSelected=$_POST['names'];
$gender=$_POST['g']; //"Male" or "Female"
$i1=$_POST['i1']; // the start of the time interval
$i2=$_POST['i2']; //the end of the time interval

require_once 'database.php';

$conn=mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');

mysql_select_db($dbname) or die ('Error, could not access database '.$dbname);

//$genderstring is a small string that we will include in our query for names that accounts for gender
$genderstring ="";
if ($gender=='Male'){
	$genderstring = "AND gender='m' ";
}else if ($gender=='Female'){
	$genderstring = "AND gender='f' ";
}

//write the query to get a list of the names in the time frame accounting for gender.
//we want two field: the name, and the sum of their percent of names across all years.  We order by the sum of those percents so that when we take the top X results, 
//we get the top X names
$query1 = "SELECT name, SUM(percent) FROM ssadata WHERE year>='".$i1."'"." AND year<='".$i2."' $genderstring GROUP BY name ORDER BY SUM(percent) DESC LIMIT 20;";
$result1= mysql_query($query1) or die('Error performing query1 on getData.php');


//create the shell of the object we are going to return.  it will be an object with 
$returnObject=new stdclass();

//Iterate through the results collecting the top 1,5, 10 or 20 names depending on the user's choice.  
$numresults =1;
if($ranks=="top5"){
	$numresults =5;
}else if($ranks=="top10"){
	$numresults =10;
}else if($ranks=="top20"){
	$numresults =20;
}else if($ranks=="None"){
	$numresults =0;
}

// Then iterate through all the names we will be using, both the ranked ones and the unranked ones.
//fill the shell with the names AND
//create a list of the names  ($namestr) we want to query for data on to use in our SQL query.
$namestr="";
//process the ranked names
for($i=0;$i<$numresults; $i++){
		$row1= mysql_fetch_row($result1);
		$thisname = $row1[0];
		$thisrank = $i +1 ; //we add one because the first rank should be 1, not 0.  
	
		$returnObject -> $thisname=new stdclass(); //the entry is called by the name.
		$returnObject -> $thisname -> label = '#'.$thisrank.' '.$thisname; //the label starts life as just a name 
		$returnObject -> $thisname -> data = array(); //the data starts as just an array.  We will add to this array when we have the data
		//put names in the name string 
		if($i==0){
			$namestr="'".$thisname."'";
		}else{
			$namestr=$namestr.",'".$thisname."'";
		}
		
}

//process the unranked names
$names = $json->decode($namesSelected);
for($i=0;$i<sizeof($names);$i++){
	$thisname = $names[$i];
	$returnObject -> $thisname=new stdclass(); //the entry is called by the name.
	$returnObject -> $thisname -> label = $thisname; //the label starts life as just a name 
	$returnObject -> $thisname -> data = array(); //the data starts as just an array.  We will add to this array when we have the data
	//put names in the name string 
	if($i==0 && $namestr==""){
		$namestr="'".$thisname."'";
	}else{
		$namestr=$namestr.",'".$thisname."'";
	}
}

//check an make sure there are names to search for

if($namestr==""){
	$returnObject -> nodata = new stdclass();
	$returnObject -> nodata ->data = array();
}else{
	//select the data with this query: name, year, percents for all the names in namelist in the range of years for the given gender
	$query2 = "SELECT name, year,percent  FROM ssadata WHERE year>='".$i1."'"." AND year<='".$i2."'  $genderstring AND name IN (".$namestr.") ORDER BY year";
	$result2= mysql_query($query2) or die('Error performing query2 on getData.php');

	//every row the the result has a name, a year and an percentage.  All we need to do is find the name in the returnObject, an add to it's data field an array with two entries, just [year, .percent]
	while($row = mysql_fetch_row($result2))
	{
		//data[] = x  will append x to the data array.
		//array((int)$row[1], (float) $row[2] );  casts the year to an int, the percent to a float and puts them both in an array.
		//this only works because we sorted $result2 by year.  The data must appear in the order it is to be graph.  
		$returnObject -> $row[0] -> data[] = array((int)$row[1], (float) $row[2] ); 
	}

	
}
$output = $json->encode($returnObject);
echo $output;
?>
