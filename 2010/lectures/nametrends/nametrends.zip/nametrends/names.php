<?php
//this must appear as the first thing in the file.  Starting a session will allow us to store data that can be used across pages.
//we will use it to store the username
session_start();
?>

<html>
<head>
<title>Baby Name Data</title>
<!-- Include core of jQuery, as well as the code (including css) for the slider and autocomplete -->
<script type="text/javascript" src="/jQuery/jquery-1.2.6.js"></script>

<link rel="stylesheet" href="/jQuery/flora.all.css" type="text/css" media="screen" title="Flora (Default)" />
<script type="text/javascript" src="/jQuery/ui.core.js"></script>
<script type="text/javascript" src="/jQuery/ui.slider.js"></script>

<link rel="stylesheet" href="/jQuery/autocomplete/jquery.autocomplete.css" type="text/css" />
<script type="text/javascript" src="/jQuery/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="/jQuery/autocomplete/jquery.autocomplete.js"></script>

<!-- The plot (called flot but it's authors) needs to be included
It is displayed using something called a canvas, if the browser is IE, we need to make canvas work in IE -->

<!--[if IE]><script language="javascript" type="text/javascript" src="../flot/excanvas.pack.js"></script><![endif]-->
<script language="javascript" type="text/javascript" src="/flot/jquery.flot.js"></script>
<script type="text/javascript" src="/json/json.js"></script>

<!-- our own css stylesheet -->
<link rel="stylesheet" text="text/css" href="style.css"/>

<script type="text/javascript">


var username= <?php
if(isset($_SESSION['username'])){
  //show that we know who the user is and that they can make comments
  echo $_SESSION['username'];
}else{
  //prompt the user the log-in or create a new account
  echo "\"\"";
}
?>

if((typeof console)=="undefined"){
    console={};
    console.log = function(){};

}

//trim takes whitespace off the beginning and end of a string using a 
//regular expression http://www.regular-expressions.info/
String.prototype.trim = function() { 
	return this.replace(/^\s+|\s+$/, ''); 
};

//store all the names the user has input in this array
var listItems= new Array();

//add a name to the list of names
function addName(){
	var name = $("#specificName").val();
	//see if the name is already in our array of items.  Only add if it's new.
	//update the model

	//loop through listItems to see if name is alreay there
	duplicate= false;	
	for(i=0; i<listItems.length; i++){
		if(listItems[i].toUpperCase()==name.toUpperCase()){
			duplicate=true;
		}
	}
	if(!duplicate){
		listItems.push(name); //add the name
		listItems.sort();  //sort the array alphabetically
		//create a table with rows for each of the list items 		
		createList()
	}
	//clear the typing in the text field
	document.getElementById('specificName').value="";
	getAndShowChart();
}

//names in listitem are unique, so we find the one instance of a particular name and splice it out.
function removeFromListItems(thisitem){
	index = 0;
	for(i=0; i<listItems.length; i++){
		if(listItems[i]==thisitem){
			index = i;
		}
	}
	listItems.splice(index, 1); //cut out 1 element at position index
};

//this displays the names in listitems by getting rid of the the GUI widget with the names,
//making a new one and attaching it in the old one's place

function createList(){
	var t = document.createElement('table');
	for(i=0; i<listItems.length; i++){		
		function blah(){
			i2=i;
			tr = document.createElement('tr');
			td1 = document.createElement('td');
			td2 = document.createElement('td');
			deleteButton = document.createElement('button');
			deleteButton.innerHTML = "X";
			deleteButton.onclick= function(){
				thisitem = this.parentNode.previousSibling.innerHTML;
				//remove the appropriate item from the list then repopulate the list
				removeFromListItems(thisitem);
				createList();
				getAndShowChart();
			}
			td1.innerHTML = listItems[i2];
			td2.appendChild(deleteButton);
			t.appendChild(tr);
			tr.appendChild(td1);
			tr.appendChild(td2)
		}
		blah();
	}
	document.getElementById('extraNames').innerHTML="";
	document.getElementById('extraNames').appendChild(t);
	if(listItems.length>0){
		clearButton = document.createElement('button');	
		clearButton.innerHTML = "ClearAll";
		clearButton.onclick= function(){
			//clear the array and
			//repopulate the chart and empty the array on the gui
			listItems=new Array();
			createList();
			getAndShowChart();
		};		
		document.getElementById('extraNames').appendChild(clearButton);
	}
}

//when the user presses Enter, call addName()
function enter(e){
	if(e.keyCode==13){
		addName()
	}	
}

//this function take data from the screen about the years, and names and refreshes the graph based on them.
function getAndShowChart(){
		var topNamesSelected = document.getElementById("selectTopNames").value;
		var namesSelected = JSON.stringify(listItems);
		var gender = $("input:radio[@name='gender']:checked").val();

		var sYear= document.getElementById("slider-min").firstChild.nodeValue;
		var eYear = document.getElementById("slider-max").firstChild.nodeValue;

		//the form is fillout out correctly, we can process it!
		//make the chart with AJAX
		$.post(
			"getData.php",
			{	ranks: topNamesSelected,
				names: namesSelected,
				g: gender,
				i1: sYear,
				i2: eYear
			},
			function(txt){
				var datasets = JSON.parse(txt);

			        $(function () {//
							

				// hard-code color indices to prevent them from shifting as
				// countries are turned on/off
				var i = 0;
				$.each(datasets, function(key, val) {
					val.color = i;
				        ++i;
				});
								
				var data = [];
				
				for(var i in datasets){
					data.push(datasets[i]);
				}
				
				console.log(data);
				if (data.length > 0)
					$.plot($("#chart"), data, {
						yaxis: { min: 0 },
						xaxis: { tickDecimals: 0 }
					});
				
				});
			}
		);  	
}

function changeGenders(){
	listItems=new Array();
	createList();
	getAndShowChart();
}

$(document).ready(function(){
	//set up the autocomplete
	$("#specificName").autocomplete("autocomplete.php",{
		mustMatch: true, //only allow the user to make selections that are on the list
		autoFill: true, 
		cacheLength: 1,
		extraParams: {gender: function(){ return $("input:radio[@name='gender']:checked").val();}}
	});
	$("#specificName").focus();
	//start the page with the chart at default valuesth
	getAndShowChart();

	//create a slider that goes form 1880 to 2006
	$('#slider').slider({ 
		stepping:1, //increment by 1 in the steps
		min: 1880,
		max: 2006,
		range: true, //show the green highlight over the range

		//with every movement of the slider, this will happen:
		slide: function(e,ui) { 
			if(e.originalTarget.id=="min-handle"){
				$("#slider-min").text(ui.value);
			};
			if(e.originalTarget.id=="max-handle"){
				$("#slider-max").text(ui.value);
			}		     	
		},

		// every time the mouse is released and on of the ranges has been changed, 
		//the chart will change to reflect the new range of years.
		change: function(e,ui) { getAndShowChart();} 
	});
    
    displayForum();
});


//functions for login

//when the user presses the "new user" button, all we have to do is 
//change the css style to make the new user form visible.
newUser = function(){
    document.getElementById("newUser").style.display="block";
    document.getElementById("newUserButton").style.display="none";
}


createAccount = function(){
	u = $('#newUsername').val();
	p = $('#newPassword').val();
	//we first need to check if that username already exists.
        $.post(
        "newUser.php",
        {	username: u,
            password: p
        },
        function(ret){
            if(ret=="success"){
                //the session variable will get set, the user will be logged in
                successfulLogin();
            }else{
                //the username is already taken
                $('#newNameMessage').empty();
                $('#newNameMessage').append('<span style="color: red">That username is taken, please try another</span>');
                //clear the inputs
                $('#newUsername').val("");
                $('#newUsername').focus();
                $('#newPassword').val("");				}
        }
    );  
}

login = function(){
	u = $('#loginUsername').val();
	p = $('#loginPassword').val();
    //we need to try to check if this username and password 
    $.post(
        "login.php",
        {	username: u,
            password: p
        },
        function(ret){
            if(ret=="success"){
                successfulLogin();
            }else{
                //the username is already taken
                $('#loginMessage').empty();
                $('#loginMessage').append('<span style="color: red">The login/password combination is not correct</span>');
                //clear the inputs
                $('#loginUsername').val("");
                $('#loginUsername').focus();
                $('#loginPassword').val("");
				}
        }
    );  
}

//after a succussful login (from either an existing or new user)
//hide the login stuff, and show the forum comment interface
successfulLogin = function(){
   //the session variable will get set, the user will be logged in
    //hide the log-in stuff
    document.getElementById("login").style.display="none";
    document.getElementById("newUser").style.display="none";
    document.getElementById("addComment").style.display="inline";
    //set the global variable, username, so that it can be displayed
    username= u;
    //show the user name in the Forum banner
    displayLoginName();
    
    //set the fields as blank for next time.
    $('#loginUsername').val("");
    $('#loginPassword').val("");
    
    $('#newUsername').val("");
    $('#newPassword').val("");
}

displayLoginName = function(){
    document.getElementById("displayName").innerHTML = u;
    document.getElementById("displayName").style.display="inline";
    document.getElementById("signOut").style.display="inline";
}

signOut = function(){
    username = null;
    document.getElementById("login").style.display="inline";
    document.getElementById("newUser").style.display="inline";
    document.getElementById("addComment").style.display="none";
    document.getElementById("displayName").style.display="none";
    document.getElementById("signOut").style.display="none";
}

//Forum functions

//The comments from the forum are dynamic data.  They come from the database. 
displayForum = function(){
    $.post(
        "getComments.php",
        {	//no post variables        
        },
        function(txt){
            var comments = JSON.parse(txt);
            console.log(comments);
            for( c in comments){                
                commentDiv = makeCommentDiv(comments[c].username, comments[c].time, comments[c].comment);
                document.getElementById('comments').appendChild(commentDiv);
            }
        }
    );  
}

makeCommentDiv = function(username, time, comment){
    commentDiv = document.createElement('div');
    commentDiv.className = "comment";
    
    commentHeader = document.createElement('div');
    commentHeader.className = "commentHeader";
    commentHeader.innerHTML = username +"&nbsp;&nbsp;&nbsp;&nbsp;"+ time;
    
    commentBody = document.createElement('div');
    commentBody.className = "commentBody";
    commentBody.innerHTML = comment;
    
    commentDiv.appendChild(commentHeader);
    commentDiv.appendChild(commentBody);
    
    return commentDiv;
}

addComment= function(){
    comment = document.getElementById('comment').value;
    console.log(comment);
    $.post(
        "newComment.php",
        {	comment: comment,
            username: username
        },
        function(txt){
            var comments = JSON.parse(txt);
            document.getElementById('comments').innerHTML=''; 
            for( c in comments){     
                           
                commentDiv = makeCommentDiv(comments[c].username, comments[c].time, comments[c].comment);
                document.getElementById('comments').appendChild(commentDiv);
            }
        }
    );  
}

</script>

</head>
<body class="flora">
<div id="top">
<div id="banner">
<img src="nametrends.gif">
</div>
<div id="collectdata">

<table>
	<tr>
		<td><b>Years</b></td>
		<td><div id='slider-min'>1880</div></td>
		<td><b>to</b></td>
		<td><div id='slider-max'>2006</div></td>
	</tr>
</table>

<table>
	<tr>
		<td>1880</td>
		<td>
			<div id='slider' class='ui-slider-2' style="margin: 0px;">
				<div id="min-handle" class='ui-slider-handle'></div>
				<div id="max-handle" class='ui-slider-handle' style="left: 188px;"></div>	
			</div>
		</td>
		<td>2006</td>
	</tr>
</table>


<table>
	<tr valign="top" >
		<td>
            <div id="gender">
                <input type="radio" name="gender" value="Male" checked="yes" onClick="changeGenders()"/>Male
                <input type="radio" name="gender" value="Female" onClick="changeGenders();"/>Female
			</div>
            <div id="names">
                <b>Names</b>
                <br>
                <select id="selectTopNames" ONCHANGE="getAndShowChart()" size="5">
                    <option id ="top1" value="top1">Most Popular Name</option>
                    <option id = "top5" value="top5" selected>Top 5 Names</option>
                    <option id = "top10" value="top10">Top 10 Names</option>
                    <option id = "top20" value="top20">Top 20 Names</option>
                    <option id= "None" value="None">None</option>
                </select>
            </div>
		</td>
	</tr>

	<tr valign="top" >
		<td>Specific Name:<br>
			<input type="text" id="specificName" onKeyPress="enter(event)"></input>
			<input type="submit" value="add" onClick="addName()"></input>
			<br>
			<div id="extraNames"></div>
		</div>

	</tr>



</table>


</div>
</div>

<div id="bottom">
<table>
    <tr>
        <td>
            <img src="percentnewborns.gif" style="padding-right: 5px">
        </td>
        <td>
            <div id="chart" style="width:600px;height:300px;"></div>
        </td>
    </tr>

    <tr>
        <td>
        
        </td>
        <td align="center">
            <img src="year.gif">
        </td>
    </tr>
</table>

<table>
    <tr>
        <td>
        <div id="login">
            <table>
            <tr>
                <td align="center" colspan="3"><div id="loginMessage">Login</div></td>
            </tr>
            <tr>
                <td>username</td>
                <td><input id="loginUsername" type="text" size="15"  maxlength = "15"></td>
            </tr>
                <td>password</td>
                <td><input id="loginPassword" type="password" size="15"  maxlength = "15"></td>
            <tr>
                <td></td>
                <td><button onclick="login()">log in</button></td>
            </tr>
            </table>
        </div>
        </td>
        
        <td>
            <button id="newUserButton" onclick="newUser()">new user?</button>
            
            <div id="newUser" style="display: none">
                
                <div id="newNameMessage">pick a username (15 characters or fewer)</div>
                <input id="newUsername" type="text" size="15"  maxlength = "15"></br>
                pick a password (15 characters or fewer)<br>
                <input id="newPassword" type="password" size="15"  maxlength = "15"></br>
                <button onclick="createAccount()">create account</button>
            </div>
        </td>
    </tr>
</table>

<div id="forum">


    <div id="forumBanner">
        <div style="float:left">
            Forum
        </div>
        <div style="float: right">
            <span id="displayName" style="display:none"></span>
            <span id="signOut" style="display:none">
                <button onClick="signOut()">logout</button>
            </span>
        </div>
    </div>

    <div id="addComment" style="display:none">
    <textarea id="comment" rows="3" cols="72"></textarea><br>
    <button onClick="addComment()">add comment</button>
    </div>

    <div id= "comments">
    </div>

</div>  
</body>
</html>
