<?php 


require_once 'functions.php';

//start the database connection
require_once 'database.php';

$username = $_POST['username'];//$_SESSION['username'];
$comment = $_POST['comment'];

$conn=mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');

mysql_select_db($dbname) or die ('Error, could not access database '.$dbname);

$returnObject = array();

$query1 = "INSERT INTO `comments` (`username` ,`time` ,`comment`) VALUES ('$username', CURRENT_TIMESTAMP , '$comment');";
$result1= mysql_query($query1) or die('Error performing query1 on newComment.php');


echo returnComments();

?>
