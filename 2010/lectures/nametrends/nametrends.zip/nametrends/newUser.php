<?php 

//start the database connection
require_once 'database.php';

$conn=mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');

$username = $_POST['username'];
$password = $_POST['password'];

mysql_select_db($dbname) or die ('Error, could not access database '.$dbname);

$returnObject = array();

//The COUNT(*) function returns the number of records in a table:
$query1 = "SELECT COUNT(*) FROM users WHERE  `username` = '$username' LIMIT 1;";
$result1= mysql_query($query1) or die('Error performing query1 on newUser.php');
$row = mysql_fetch_row($result1);
$numMatches = $row[0];
$return="success";
if($numMatches=="1"){
	//sname already exists
	$return ="fail";
}else{
	//insert the new name into the users table and then set the session variable
	$query2 = "INSERT INTO users VALUES ('$username' , '$password')";
	$result2= mysql_query($query2) or die('Error performing query1 on getData.php');
	$_SESSION['username']=$username;
	
}

echo $return;
?>
