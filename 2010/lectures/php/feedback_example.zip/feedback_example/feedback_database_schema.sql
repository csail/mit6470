# CocoaMySQL dump
# Version 0.7b5
# http://cocoamysql.sourceforge.net
#
# Host: sql.mit.edu (MySQL 5.1.35-log)
# Database: _username_+feedback
# Generation Time: 2010-01-13 18:06:22 -0500
# ************************************************************

# Dump of table comments
# ------------------------------------------------------------

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `content` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table users
# ------------------------------------------------------------

CREATE TABLE `users` (
  `id` int(25) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(25) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `logins` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`email`),
  KEY `last_name` (`last_name`),
  FULLTEXT KEY `first_name` (`first_name`),
  FULLTEXT KEY `last_name_2` (`last_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



