<?php

	/**********************
	 Written by Yafim Landa
	 for MIT 6.470, IAP '10
	 PHP Lecture,  1/5/2010
	***********************/

	session_start(); // Must include this call every time we work with sessions
	
	ini_set('display_errors', 1);
	error_reporting(E_ALL);
	
	define('PATH_TO_APP', '/6.470/feedback'); // Where the web application is located on the server.
	
	include_once 'database.php'; // Include our database code
	
	// If the user is here, we want to log them out and then prompt them
	// to log back in, perhaps with a different account.

	$_SESSION = array(); // Reset the $_SESSION array to a blank variable

	// If they're using HTTPS, then it must mean that they're trying to log in
	// using their MIT certificates.
	if (array_key_exists('HTTPS', $_SERVER)) {
		$fullname = explode(" ", $_SERVER['SSL_CLIENT_S_DN_CN']);
		$first_name = $fullname[0];
		$last_name = $fullname[count($fullname)-1];
		$email = $_SERVER['SSL_CLIENT_S_DN_Email'];
		
		// Remember everything we need in the $_SESSION variable
		$_SESSION['first_name'] = $first_name;
		$_SESSION['last_name'] = $last_name;
		$_SESSION['email'] = $email;
		
		// Okay, now that we've saved this info in the session, let's make a record
		// in the database.
		$thequery = "INSERT INTO users
					 (first_name, last_name, email)
					 VALUES ('$first_name', '$last_name', '$email')
					 ON DUPLICATE KEY UPDATE logins=logins+1";
		mysql_query($thequery) or die(mysql_error()); // Make the query and short circuit out or die with the error
		$_SESSION['id'] = mysql_insert_id(); // Get the id from the row we just inserted or updated
		
		// Now we just have to redirect the user back to wherever they came from.
		// We are going to do this a simple way and just send them back to index.php,
		// but you could pass a return address as a GET parameter.
		$url = 'http://' . $_SERVER['SERVER_NAME'] . PATH_TO_APP . '/index.php';
		header("Location: $url");
	}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">

<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Feedback | log in</title>
	<link href="css/main.css" rel="stylesheet" type="text/css" />
	<script src="javascript/prototype.js" type="text/javascript"></script>
	<script src="javascript/scriptaculous.js?load=effects,controls" type="text/javascript"></script>
	<script src="javascript/main.js" type="text/javascript"></script>
	<link rel="shortcut icon" href="favicon.ico" />
</head>
<body>
	<div style="padding: 30px">
		<img src="images/logo.png"/><br/><br/>
		<a href="https://<?php echo $_SERVER['SERVER_NAME'] . ':444' . $_SERVER['PHP_SELF']?>">Click here</a> to login with your MIT certificates.
	</div>
</body>
</html>
