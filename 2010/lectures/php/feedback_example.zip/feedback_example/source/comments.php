<?php

// Error reporting for debugging purposes
// Uncomment to display errors
// ini_set('display_errors',1);
// error_reporting(E_ALL);

include_once 'database.php';

// Retrieve the limit from the GET parameter.
$limit = $_GET['limit'];
if (!isset($limit)) $limit = 10; // Set it to 10 if it's empty

$query = "SELECT * FROM comments, users
		  WHERE comments.user_id = users.id
		  ORDER BY comments.id DESC
		  LIMIT $limit";

$sql = mysql_query($query); // Make the MySQL call here

// Load the data into an associative array
$results = array();
while($row = mysql_fetch_array($sql)) {
	$entry = array(); // A single comment
	$entry["first_name"] = $row["first_name"];
	$entry["last_name"] = $row["last_name"];
	$entry["comment"] = $row["content"];
	$results[] = $entry;
}

// Okay, now we have an array of comments
// let's print it out in JSON format. We
// will use json_encode for that.

echo json_encode($results);

?>