<?php

	/**********************
	 Written by Yafim Landa
	 for MIT 6.470, IAP '10
	 PHP Lecture,  1/5/2010
	***********************/

	session_start();
	
	include_once 'database.php';
	
	define('PATH_TO_APP', '/6.470/feedback'); // Where the web application is located on the server.
	
	// Is the user logged in? They are if their email is set in the session variable.
	$logged_in = isset($_SESSION['email']);
	
	if ($logged_in && isset($_POST['comment'])) {
		// If a comment was submitted, then write it to the database using the logged-in user's name.
		$sql = mysql_query("INSERT INTO comments (user_id, content) VALUES ('" . $_SESSION['id'] . "', '" . $_POST['comment'] . "')");
	}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">

<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Feedback</title>
	<link href="css/main.css" rel="stylesheet" type="text/css" />
	<script src="javascript/prototype/prototype.js" type="text/javascript"></script>
	<script src="javascript/scriptaculous/scriptaculous.js?load=effects,controls" type="text/javascript"></script>
	<script src="javascript/main.js" type="text/javascript"></script>
	<link rel="shortcut icon" href="favicon.ico" />
</head>
<body>
	<center>
		<div id="container">
			<div id="logo">
				<div id="top">
					<a href="http://<?php echo $_SERVER['SERVER_NAME'] . PATH_TO_APP ?>"><img border="0" src="images/logo.png"/></a>
				</div>
				<div id="stats">
					<?php
						
						if ($logged_in) {
							// We want to display some basic information about the user.
							// Let's show them their first and last names, their email
							// address, and the number of times they've used the system.

							// To get that last one, we need to query the database. We
							// want to SELECT logins from the 'users' table WHERE the id
							// is the one that matches the id of our user.

							$id = $_SESSION['id'];
							$sql = mysql_query("SELECT logins FROM users WHERE id='$id'");
							$obj = mysql_fetch_object($sql);
							$visits = $obj->logins;

							echo '<center><u>' . $_SESSION['first_name'] . ' ' . $_SESSION['last_name'] . '</u><br/>';
							echo $_SESSION['email'] . '<br/>';
							echo 'Visited ' . $visits . ' times</center>';
						}
						else {
							
							// The user is not logged in. Show general information about the website instead of
							// the user's available account information.
							
							?>
							
								Feedback allows you to post your thoughts for other people to see.
							
							<?php
						}

					?>
				</div>
				<div id="controls">
				<?php
				
					if ($logged_in) {
						
						?>
						
							<input type="button" value="Log out" onclick="window.location = 'logout.php'"/>
						
						<?php
					}
					else {
						?>
						
							<input type="button" value="Log in" onclick="window.location = 'auth.php'"/>
						
						<?php
					}
				
				?>
				</div>
				<div style="clear: both"> </div>
			</div>
			<div id="lectures">
				<?php
				
					// If the user is logged in, we should let them post something.
					if ($logged_in) {
						?>
						
						<form action="http://<?php echo $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF']; ?>" method="post">
							<center><textarea name="comment" class="quickwrite">Write something here</textarea>
							<input type="submit" style="float: right; position: relative; left: 22px" value="Post"/></center>
						</form>
						
						<?php
					}
				
					// Show what people have said
					$sql = mysql_query("SELECT * FROM comments,users WHERE users.id = comments.user_id ORDER BY comments.id DESC");
					if (mysql_num_rows($sql) == 0) echo "No one has said anything, yet.";
					else {
						while ($obj = mysql_fetch_object($sql)) {
							echo '<a href="mailto:' . $obj->email . '">' . $obj->first_name . ' ' . $obj->last_name . '</a> said &#8220;' . nl2br(htmlspecialchars($obj->content)) . '&#8221;<br/>';
						}
					}
				
				?>
			</div>
			<div style="clear: both"> </div>
		</div>
		<div style="clear: both"> </div>
	</center>
</body>
</html>
