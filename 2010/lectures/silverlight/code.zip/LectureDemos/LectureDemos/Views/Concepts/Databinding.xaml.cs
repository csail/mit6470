﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.Threading;
using System.Windows.Data;
using System.ComponentModel;

namespace LectureDemos.Concepts
{
    public partial class Databinding : Page
    {
        public Clock cl;
        public Databinding()
        {
            InitializeComponent();
            cl = new Clock();

            Timer t = new Timer(new TimerCallback(Callback), null, 0, 1000);

            this.DataContext = cl;
        }

        public void Callback(object state)
        {
            this.Dispatcher.BeginInvoke(new Action(delegate()
                {
                    cl.Time = DateTime.Now;
                }));
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

    }

    public class DateTimeConverter : IValueConverter
    {
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            DateTime time = (DateTime)value;
            return time.ToLongTimeString();
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }


    public class Clock : INotifyPropertyChanged
    {
        public DateTime _time;
        public DateTime Time
        {
            get
            {
                return _time;
            }
            set
            {
                if (_time != value)
                {
                    if (PropertyChanged != null)
                    {
                        PropertyChanged(this, new PropertyChangedEventArgs("Time"));
                    }
                    _time = value;
                }
            }

        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }

}
