﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace LectureDemos
{
	public partial class BorderExample : UserControl
	{
		public BorderExample()
		{
			// Required to initialize variables
			InitializeComponent();
		}

        private void LayoutRoot_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {

        }
	}
}