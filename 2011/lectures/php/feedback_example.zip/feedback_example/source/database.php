<?php

// Please replace _username_ and _password_ with your username and password.
define('USERNAME', '_username_');
define('PASSWORD', '_password_');

$dbh = mysql_connect('sql.mit.edu', USERNAME, PASSWORD) or die('Could not connect: ' . mysql_error() . '<br />');
mysql_select_db(USERNAME . '+feedback') or die('No database selected.');

?>