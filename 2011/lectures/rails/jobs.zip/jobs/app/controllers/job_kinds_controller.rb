class JobKindsController < ApplicationController
  # GET /job_kinds
  # GET /job_kinds.xml
  def index
    @job_kinds = JobKind.all

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @job_kinds }
    end
  end

  # GET /job_kinds/1
  # GET /job_kinds/1.xml
  def show
    @job_kind = JobKind.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @job_kind }
    end
  end

  # GET /job_kinds/new
  # GET /job_kinds/new.xml
  def new
    @job_kind = JobKind.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @job_kind }
    end
  end

  # GET /job_kinds/1/edit
  def edit
    @job_kind = JobKind.find(params[:id])
  end

  # POST /job_kinds
  # POST /job_kinds.xml
  def create
    @job_kind = JobKind.new(params[:job_kind])

    respond_to do |format|
      if @job_kind.save
        format.html { redirect_to(@job_kind, :notice => 'Job kind was successfully created.') }
        format.xml  { render :xml => @job_kind, :status => :created, :location => @job_kind }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @job_kind.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /job_kinds/1
  # PUT /job_kinds/1.xml
  def update
    @job_kind = JobKind.find(params[:id])

    respond_to do |format|
      if @job_kind.update_attributes(params[:job_kind])
        format.html { redirect_to(@job_kind, :notice => 'Job kind was successfully updated.') }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @job_kind.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /job_kinds/1
  # DELETE /job_kinds/1.xml
  def destroy
    @job_kind = JobKind.find(params[:id])
    @job_kind.destroy

    respond_to do |format|
      format.html { redirect_to(job_kinds_url) }
      format.xml  { head :ok }
    end
  end
end
