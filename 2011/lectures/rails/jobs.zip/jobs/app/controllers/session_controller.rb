class SessionController < ApplicationController
  def index
    if session[:profile_id]
      redirect_to :controller => :profiles, :action => :show, :id => session[:profile_id]
    else
      redirect_to :controller => :profiles, :action => :new
    end
  end

  def home
  end

end
