module JobKindsHelper
end
