class Job < ActiveRecord::Base
  def self.jobs_from_monster(url)
    m = Mechanize.new
    m.user_agent_alias = 'Mac FireFox'
    doc = m.get url
    names = doc.root.css('#jobSearchresult div.companyName').map { |div| div.attr('title') }
    locations = doc.root.css('#jobSearchresult div.jobPlace').map { |div| div.attr('title') }
    names.zip locations
  end
  
  belongs_to :job_kind
  
  def self.populate(url, kind)
    jobs_from_monster(url).each do |job_data|
      job = Job.new :company => job_data[0], :location => job_data[1],
                    :job_kind => kind
      job.save!
    end
  end
end
