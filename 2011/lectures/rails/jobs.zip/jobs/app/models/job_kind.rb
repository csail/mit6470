class JobKind < ActiveRecord::Base
  def self.kinds_from_monster
    m = Mechanize.new
    m.user_agent_alias = 'Mac FireFox'
    doc = m.get 'http://monster.com'
    Hash[doc.root.css('#browseJobs a[name=bjcat_link]').map {|link|
      [link.inner_text, link.attr('href')]
    }]
  end
  
  has_many :jobs
  
  def self.populate
    JobKind.destroy_all
    Job.destroy_all
    kinds_from_monster.each { |k, v|
      kind = JobKind.new :name => k
      kind.save!
      Job.populate v, kind
    }
  end
end
