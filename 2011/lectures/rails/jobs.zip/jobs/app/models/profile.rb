class Profile < ActiveRecord::Base
  belongs_to :job_kind
end
