# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Jobs::Application.config.secret_token = '50b4a88a66afcbc0c4d13dd4dee9ba1d08a5d0e010ca5acf6d2bf01eae43efa689eec8f0597a58ced0e6ab2ee643940f0143a0a91a33ca95889bd3c981d87d99'
