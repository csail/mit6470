require 'test_helper'

class JobKindsControllerTest < ActionController::TestCase
  setup do
    @job_kind = job_kinds(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:job_kinds)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create job_kind" do
    assert_difference('JobKind.count') do
      post :create, :job_kind => @job_kind.attributes
    end

    assert_redirected_to job_kind_path(assigns(:job_kind))
  end

  test "should show job_kind" do
    get :show, :id => @job_kind.to_param
    assert_response :success
  end

  test "should get edit" do
    get :edit, :id => @job_kind.to_param
    assert_response :success
  end

  test "should update job_kind" do
    put :update, :id => @job_kind.to_param, :job_kind => @job_kind.attributes
    assert_redirected_to job_kind_path(assigns(:job_kind))
  end

  test "should destroy job_kind" do
    assert_difference('JobKind.count', -1) do
      delete :destroy, :id => @job_kind.to_param
    end

    assert_redirected_to job_kinds_path
  end
end
