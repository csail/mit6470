require 'test_helper'

class JobKindsHelperTest < ActionView::TestCase
end
