<?php
$host = '127.0.0.1';
$username = 'root';
$password = '';
$db = mysql_connect($host, $username, $password) or die('Could not connect: ' . mysql_error());
mysql_select_db('6470+quickpolls');
?>