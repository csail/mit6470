<?php require 'db.php'; ?>

<html>
	<head>
		<title>Quick Polls</title>
	</head>
	<body>
		<h1>Quick Polls</h1>
		<h2>Active Polls</h2>
		
		<ul>
		<?php
		$query = "SELECT * FROM polls";
		$result = mysql_query($query) or die(mysql_error());
		while ($row = mysql_fetch_array($result)) {
			$poll_id = $row['poll_id'];
			echo '<li>';
			echo "<a href='poll.php?poll_id=$poll_id'>".$row['poll_name'].'</a>';
			echo '</li>';
		}
		
		mysql_close($db);
		?>
		</ul>
		
	</body>
</html>