<?php require 'db.php'; ?>

<html>
	<head>
		<title>Quick Polls</title>
	</head>
	<body>
		<h1>Quick Polls</h1>
		<h2>Active Polls</h2>
		
		<ul>
		<?php
		$query = "SELECT * FROM polls";
		$result = mysql_query($query) or die(mysql_error());
		while ($row = mysql_fetch_array($result)) {
			$poll_id = $row['poll_id'];
			echo '<li>';
			echo "<a href='poll.php?poll_id=$poll_id'>".$row['poll_name'].'</a>';
			echo '</li>';
		}
		?>
		</ul>
		
		<h2>Selected Poll</h2>
		<?php
		$poll_id = $_GET['poll_id'];
		$query = "SELECT * FROM polls WHERE poll_id=$poll_id";
		$result = mysql_query($query);
		$row = mysql_fetch_array($result);
		echo $row['question'];
		?>
		
	</body>
</html>